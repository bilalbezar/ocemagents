/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author jMaster
 */
public class Simulator extends JPanel {
    
    public static JTextArea statusArea;
    private String[] header = { "Path", "Cost" };
    private String[] paths = { "H-h1", "H-h2", "H-h3", "H-h4", "H-h5", "h1-h2", "h1-h3", "h1-h4", "h1-h5", "h2-h3", "h2-h4", "h2-h5", "h3-h4", "h3-h5", "h4-h5" };
    private int[] costs;
    private JTable costTable;
    private Object[][] data;
    private JScrollPane tablePane;
    private JButton newSim, settings, addAgent, startSim, stopSim;
    private UIManager.LookAndFeelInfo looks[];

    private int[][] hostPaths = { { 290, 165, 130, 220 }, { 370, 165, 530, 220 }, { 330, 190, 130, 320 }, { 330, 190, 530, 320 }, { 330, 190, 330, 400 }, { 170, 245, 490, 245 }, { 130, 270, 130, 320 }, { 170, 245, 490, 345 }, { 130, 270, 330, 400 }, { 490, 245, 170, 345 }, { 530, 270, 530, 320 }, { 530, 270, 330, 400 }, { 170, 345, 490, 345 }, { 130, 370, 290, 425 }, { 530, 370, 370, 425 } };
    
    private String[] agentNames = { "A", "B", "C", "D", "E", "F" };
    private int agentCounter = 0;
    private Agent[] agents;
    private int[][] agentA = { { 310, 140 }, { 110, 220 }, { 510, 220 }, { 110, 320 }, { 510, 320 }, { 310, 400 } };
    private int currentA = 0;
    private int[][] agentB = { { 335, 140 }, { 135, 220 }, { 535, 220 }, { 135, 320 }, { 535, 320 }, { 335, 400 }  };
    private int currentB = 0;
    private int[][] agentC = { { 290, 158 }, { 90, 238 }, { 490, 238 }, { 90, 338 }, { 490, 338 }, { 290, 418 }  };
    private int currentC = 0;
    private int[][] agentD = { { 355, 158 }, { 155, 238 }, { 555, 238 }, { 155, 338 }, { 555, 338 }, { 355, 418 }  };
    private int currentD = 0;
    private int[][] agentE = { { 310, 175 }, { 110, 255 }, { 510, 255 }, { 110, 355 }, { 510, 355 }, { 310, 435 } };
    private int currentE = 0;
    private int[][] agentF = { { 335, 175 }, { 135, 255 }, { 535, 255 }, { 135, 355 }, { 535, 355 }, { 335, 435 }  };
    private int currentF = 0;

    private int[] migratingPath = new int[ 4 ];
    private Color migratingColor = null;
    
    private Recorder statPane;
    
    public Simulator( Recorder statPane ) {
        this.setLayout( null );
        
        this.statPane = statPane;
        
        JLabel simLabel = new JLabel( "Simulation Log", SwingConstants.CENTER );
        simLabel.setBounds( 10, 5, 930, 20 );
        simLabel.setFont( new Font( "Arial", Font.BOLD, 16 ) );
        this.add( simLabel );
        statusArea = new JTextArea( "All the simulation activities will be logged here!\n" );
        statusArea.setEditable( false );
        statusArea.setWrapStyleWord( true );
        statusArea.setLineWrap( true );
        JScrollPane scroll = new JScrollPane( statusArea );
        scroll.setBounds( 10, 25, 930, 100 );
        this.add( scroll );

        JLabel costLabel = new JLabel( "Cost Table", SwingConstants.CENTER );
        costLabel.setBounds( 720, 140, 200, 20 );
        costLabel.setFont( new Font( "Arial", Font.BOLD, 16 ) );
        this.add( costLabel );
        
        data = new Object[ 15 ][ 2 ];
        costs = new int[ 15 ];
        for( int i=0; i<15; i++ ) {
            data[ i ][ 0 ] = paths[ i ];
            data[ i ][ 1 ] = 0;
            costs[ i ] = 0;
        } //END for LOOP
        costTable = new JTable( data, header );
        tablePane = new JScrollPane( costTable );
        tablePane.setBounds( 720, 160, 200, 280 );
        this.add( tablePane );
        
        JSeparator js = new JSeparator();
        js.setBounds( 0, 470, 950, 2 );
        this.add( js );
        
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout( null );
        controlPanel.setBounds( 10, 480, 930, 90 );
        controlPanel.setBorder( BorderFactory.createTitledBorder( "  Control Panel  " ));
        this.add( controlPanel );
        
        ImageIcon newSimI = new ImageIcon( "NewSim.png" );
        newSim = new JButton( newSimI );
        newSim.setToolTipText( "New Simulation Prject" );
        newSim.setBounds( 15, 15, 70, 70 );
        controlPanel.add( newSim );
        ImageIcon addAgentI = new ImageIcon( "AddAgent.png" );
        addAgent = new JButton( addAgentI );
        addAgent.setToolTipText( "Add an Agent to Simulation" );
        addAgent.setBounds( 100, 15, 70, 70 );
        addAgent.setEnabled( false );
        controlPanel.add( addAgent );
        
        ImageIcon startSimI = new ImageIcon( "StartSim.png" );
        startSim = new JButton( startSimI );
        startSim.setToolTipText( "Start the Simulation" );
        startSim.setBounds( 185, 15, 70, 70 );
        startSim.setEnabled( false );
        controlPanel.add( startSim );
        ImageIcon stopSimI = new ImageIcon( "StopSim.png" );
        stopSim = new JButton( stopSimI );
        stopSim.setToolTipText( "Stop the Simulation" );
        stopSim.setBounds( 270, 15, 70, 70 );
        stopSim.setEnabled( false );
        controlPanel.add( stopSim );

        ImageIcon settingsI = new ImageIcon( "Settings2.png" );
        settings = new JButton( settingsI );
        settings.setToolTipText( "Prject Settings" );
        settings.setBounds( 840, 15, 70, 70 );
        controlPanel.add( settings );
        
        agents = new Agent[ OCEMAgentsConstants.NUMBER_AGENTS ];
        
        newSim.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        startNewSimulation();
                    }
                }
        );
        
        addAgent.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        addAgent();
                    }
                }
        );
        
        startSim.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        startSimulation();
                    }
                }
        );
        
        stopSim.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        stopSimulation();
                    }
                }
        );
        
        settings.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        ConfigOCEMAgents config = new ConfigOCEMAgents( new JFrame() );
                    }
                }
        ); 
        
        this.repaint();
        
        looks = UIManager.getInstalledLookAndFeels();
        try {
            UIManager.setLookAndFeel( looks[ 3 ].getClassName() );
            SwingUtilities.updateComponentTreeUI( this );
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCk
        
    } //END SimulationPane() CONSTRUCTOR
    
    public class Agent extends Thread {

        private String name;
        private String previousHostString, currentHostString, shortestPath;
        private int previousHost, currentHost, totalStay, currentStay;
        private int noOfMigrations, previousHostCost, currentHostCost, shortestPathCost;
        private int noOfUpdateMessages, updateMessageCostBase, updateMessageCostProp;
        private int noOfMessages, messageCostBase, messageCostProp, shortestPathCostPenalty;
        private int noOfAcks, ackCostProp, ackCostBase;
        
        private String[] hosts = { "H", "h1", "h2", "h3", "h4", "h5" };
        
        boolean updateMessageSent, shortestPathCalculated=false;
        
        public Agent( String n ) {
            name = n;
        } //END Agent() CONSTRUCTOR
        
        public String getAgentName() {
            return name;
        } //END getAgentName() METHOD
        
        public int getNoOfMigrations() {
            return noOfMigrations;
        } //END getNoOfMigrations() METHOD
        
        public int getNoOfUpdateMessages() {
            return noOfUpdateMessages;
        } //END getNoOfUpdateMessages() METHOD
        
        public int getUpdateMessageCostBase() {
            return updateMessageCostBase;
        } //END getUpdateMessageCostBase() METHOD
        
        public int getUpdateMessageCostProp() {
            return updateMessageCostProp;
        } //END getUpdateMessageCostProp() METHOD
        
        public int getNoOfMessages() {
            return noOfMessages;
        } //END getNoOfMessages() METHOD
        
        public int getMessageCostBase() {
            return messageCostBase;
        } //END getMessageCostBase() METHOD
        
        public int getMessageCostProp() {
            return messageCostProp; 
        } //END getMessageCostProp() METHOD
        
        public int getShortestPathCostPenalty() {
            return shortestPathCostPenalty;
        } //END getShortestPathCostPenalty() METHOD
        
        public int getNoOfAcks() {
            return noOfAcks;
        } //END getNoOfAcks() METHOD
        
        public int getAckCostProp() {
            return ackCostProp;
        } //END getAckCostProp() METHOD
        
        public int getAckCostBase() {
            return ackCostBase;
        } //END getAckCostBase() METHOD
        
        public void run() {
            /* THIS CODE IS FOR THE first migration OF THE AGENT */
            try {
                Thread.sleep( 2000 );
            } catch( Exception e ) {
                e.printStackTrace();
            } //END try-catch BLOCK
            int newHost = -1;
            if( OCEMAgentsConstants.SIMULATION_RUNNING ) {
                newHost = ( int )( Math.random() * 6 );
                if( newHost==0 ) {
                    newHost++;
                } //END if STATEMENT
            } //END if STATEMENT
            statusArea.append( "MIGRATION: The Agent " + this.name + " is migrating to Host-" + newHost + ".\n" );
            statusArea.setText( statusArea.getText() );
            if( newHost==1 ) {
                migratingPath[ 0 ] = hostPaths[ 0 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 0 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 0 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 0 ][ 3 ];
            } else if( newHost==2 ) {
                migratingPath[ 0 ] = hostPaths[ 1 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 1 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 1 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 1 ][ 3 ];
            } else if( newHost==3 ) {
                migratingPath[ 0 ] = hostPaths[ 2 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 2 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 2 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 2 ][ 3 ];
            } else if( newHost==4 ) {
                migratingPath[ 0 ] = hostPaths[ 3 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 3 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 3 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 3 ][ 3 ];
            } else {
                migratingPath[ 0 ] = hostPaths[ 4 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 4 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 4 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 4 ][ 3 ];
            } //END if-else-if STATEMENT
            if( this.name.equals( "A" ) ) {
                migratingColor = Color.RED;
            } else if( this.name.equals( "B" ) ) {
                migratingColor = Color.BLUE;
            } else if( this.name.equals( "C" ) ) {
                migratingColor = Color.GREEN;
            } else if( this.name.equals( "D" ) ) {
                migratingColor = Color.ORANGE;
            } else if( this.name.equals( "E" ) ) {
                migratingColor = Color.MAGENTA;
            } else {
                migratingColor = Color.YELLOW;
            } //END if-else-if STATEMENT
            Simulator.this.repaint();
            try {
                Thread.sleep( 2000 );
            } catch( Exception e ) {
                e.printStackTrace();
            } //END try-catch BLOCK
            statusArea.append( "MIGRATION: The Agent " + this.name + " has migrated to Host-" + newHost + ".\n" );
            statusArea.setText( statusArea.getText() );
            migratingColor = null;
            if( this.name.equals( "A" ) ) {
                currentA = newHost;
            } else if( this.name.equals( "B" ) ) {
                currentB = newHost;                
            } else if( this.name.equals( "C" ) ) {
                currentC = newHost;
            } else if( this.name.equals( "D" ) ) {
                currentD = newHost;
            } else if( this.name.equals( "E" ) ) {
                currentE = newHost;
            } else {
                currentF = newHost;
            } //END if-else-if STATEMENT
            Simulator.this.repaint();
            /* THIS CODE IS FOR THE first migration OF THE AGENT */

            statPane.generateUpdateCostTable( agents );
            statPane.generateForwardingPointersTable( agents );

            previousHost = 0;
            currentHost = newHost;
            previousHostCost = costs[ currentHost-1 ];
            currentHostCost = costs[ currentHost-1 ];
            updateMessageCostBase = currentHostCost;
            noOfMigrations = 1;
            shortestPath = "H-" + hosts[ newHost ];
            shortestPathCost = previousHostCost;
            updateMessageSent = false;
            noOfUpdateMessages = 0;
            
            /* THIS CODE IS FOR THE life-cycle OF THE AGENT */
            while( OCEMAgentsConstants.SIMULATION_RUNNING ) {
                
                //Calculating duration of the total stay on current host
                totalStay = ( int )( Math.random() * OCEMAgentsConstants.AGENT_TOTAL_STAY );
                if( totalStay<OCEMAgentsConstants.MIN_STAY_BEFORE_MIGRATION ) {
                    totalStay = OCEMAgentsConstants.MIN_STAY_BEFORE_MIGRATION;
                } //END if STATEMENT
                
                if( totalStay>=OCEMAgentsConstants.UPDATE_TIMEOUT ) {
                    noOfUpdateMessages++;
                } //END if STATEMENT
                
                //Iterating the total stay of an agent on the current host
                for( currentStay=1; currentStay<=totalStay; ) {
                    try {
                        Thread.sleep( 200 );
                    } catch( Exception e ) {
                        e.printStackTrace();
                    } //END try-catch BLOCK
                    currentStay++;
                    
                    //Sending Update Message
                    if( currentStay==OCEMAgentsConstants.UPDATE_TIMEOUT ) {
                        statusArea.append( "UPDATE MESSAGE: The Agent " + this.name + " is sending update message to H.\n" );
                        statusArea.setText( statusArea.getText() );
                        previousHostString = hosts[ previousHost ] + "-" + hosts[ currentHost ];
                        currentHostString = "H-" + hosts[ currentHost ];
                        updateMessageSent = true;
                        updateMessageCostProp += currentHostCost;
                    } //END if STATEMENT

                    //Calculating Shortest Path
                    if( currentStay==OCEMAgentsConstants.UPDATE_TIMEOUT ) {
                        statusArea.append( "SHORTEST PATH: H is going to calculate shortest path for Agent " + this.name + ".\n" );
                        statusArea.setText( statusArea.getText() );
                        
                        if( noOfMigrations>1 ) {
                            if( ( previousHostCost+shortestPathCost ) < currentHostCost ) {
                                shortestPathCost = previousHostCost+shortestPathCost;
                                shortestPath = shortestPath + ", " + previousHostString;
                            } else {
                                shortestPathCost = currentHostCost;
                                shortestPath = currentHostString;
                            } //END if-else STATEMENT
                        } //END if STATEMENT
                        
                        statusArea.append( "INFO: The shortest path from H to the Agent " + this.name + " is " + shortestPath + " with Cost " + shortestPathCost + ".\n" );
                        statusArea.setText( statusArea.getText() );
                        shortestPathCostPenalty += shortestPathCost;
                        
                        shortestPathCalculated = true;
                    } //END if STATEMENT
                    
                    //Agent is Sending a Message to LMS
                    if( currentStay%4==0 && currentStay!=OCEMAgentsConstants.UPDATE_TIMEOUT ) {
                        byte messageDecision = ( byte )( Math.random() * 2 );
                        if( messageDecision==1 || shortestPathCalculated ) {
                            statusArea.append( "MESSAGE: The Agent " + this.name + " is sending a message to H.\n" );
                            statusArea.setText( statusArea.getText() );
                            
                            noOfMessages++;
                            messageCostBase += currentHostCost;
                            if( shortestPathCalculated ) {
                                messageCostProp += shortestPathCost;
                                statusArea.append( "MESSAGE: The Agent " + this.name + " has sent a message to H with cost: " + shortestPathCost + ".\n" );
                            } else {
                                messageCostProp += currentHostCost;
                                statusArea.append( "MESSAGE: The Agent " + this.name + " has sent a message to H with cost: " + currentHostCost + ".\n" );
                            } //END if-else STATEMENT
                            
                            try {
                                Thread.sleep( 500 );
                            } catch( Exception e ) {
                                e.printStackTrace();
                            } //END try-catch BLOCK                            
                            
                            statusArea.setText( statusArea.getText() );
                            
                            statPane.generateMessageCostTable( agents );
                            
                            //Generating random value for acknolwedgement
                            messageDecision = ( byte )( Math.random() * 3 );
                            if( messageDecision==0 || messageDecision==2 ) {
                                statusArea.append( "ACK: H is sending an acknowledgement to the Agent " + this.name + " .\n" );
                                statusArea.setText( statusArea.getText() );
                                
                                noOfAcks++;
                                if( shortestPathCalculated ) {
                                    ackCostProp += shortestPathCost;
                                } else {
                                    ackCostProp += currentHostCost;
                                } //END if-else STATEMENT
                                
                                statusArea.append( "ACK: The acknowledgement from H has been received by the Agent " + this.name + " .\n" );
                                statusArea.setText( statusArea.getText() );
                            } //END if STATEMENT
                            ackCostBase += currentHostCost;
                            statPane.generateAcknowledgementCostTable( agents );
                            
                        } //END if STATEMENT
                    } //END if STATEMENT
                    //Message Sending Code Ends Here!
                    
                } //END for LOOP
                
                //Migrating Agent to another Host
                do {
                    newHost = ( int )( Math.random() * 6 );
                    if( newHost==0 )
                        newHost++;
                } while( newHost==currentHost );
                previousHost = currentHost;
                currentHost = newHost;
                calculatePreviousAndCurrentHostCosts();
                performMigration( newHost );
                
                statPane.generateUpdateCostTable( agents );
                statPane.generateForwardingPointersTable( agents );
                
                noOfMigrations++;
                updateMessageSent = false;
                shortestPathCalculated = false;
                updateMessageCostBase += currentHostCost;

            } //END while LOOP
            /* THIS CODE IS FOR THE life-cycle OF THE AGENT */

        } //END run() METHOD
        
        public void performMigration( int newHost ) {
            statusArea.append( "MIGRATION: The Agent " + this.name + " is migrating to Host-" + newHost + ".\n" );
            statusArea.setText( statusArea.getText() );
            if( ( previousHost==1 && currentHost==2 ) || ( previousHost==2 && currentHost==1 ) ) {
                migratingPath[ 0 ] = hostPaths[ 5 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 5 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 5 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 5 ][ 3 ];
            } else if( ( previousHost==1 && currentHost==3 ) || ( previousHost==3 && currentHost==1 ) ) {
                migratingPath[ 0 ] = hostPaths[ 6 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 6 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 6 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 6 ][ 3 ];
            } else if( ( previousHost==1 && currentHost==4 ) || ( previousHost==4 && currentHost==1 ) ) {
                migratingPath[ 0 ] = hostPaths[ 7 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 7 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 7 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 7 ][ 3 ];
            } else if( ( previousHost==1 && currentHost==5 ) || ( previousHost==5 && currentHost==1 ) ) {
                migratingPath[ 0 ] = hostPaths[ 8 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 8 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 8 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 8 ][ 3 ];
            } else if( ( previousHost==2 && currentHost==3 ) || ( previousHost==3 && currentHost==2 ) ) {
                migratingPath[ 0 ] = hostPaths[ 9 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 9 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 9 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 9 ][ 3 ];
            } else if( ( previousHost==2 && currentHost==4 ) || ( previousHost==4 && currentHost==2 ) ) {
                migratingPath[ 0 ] = hostPaths[ 10 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 10 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 10 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 10 ][ 3 ];
            } else if( ( previousHost==2 && currentHost==5 ) || ( previousHost==5 && currentHost==2 ) ) {
                migratingPath[ 0 ] = hostPaths[ 11 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 11 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 11 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 11 ][ 3 ];
            } else if( ( previousHost==3 && currentHost==4 ) || ( previousHost==4 && currentHost==3 ) ) {
                migratingPath[ 0 ] = hostPaths[ 12 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 12 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 12 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 12 ][ 3 ];
            } else if( ( previousHost==3 && currentHost==5 ) || ( previousHost==5 && currentHost==3 ) ) {
                migratingPath[ 0 ] = hostPaths[ 13 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 13 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 13 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 13 ][ 3 ];
            } else if( ( previousHost==4 && currentHost==5 ) || ( previousHost==5 && currentHost==4 ) ) {
                migratingPath[ 0 ] = hostPaths[ 14 ][ 0 ]; migratingPath[ 1 ] = hostPaths[ 14 ][ 1 ]; migratingPath[ 2 ] = hostPaths[ 14 ][ 2 ]; migratingPath[ 3 ] = hostPaths[ 14 ][ 3 ];
            } //END if-else-if STATEMENT
            if( this.name.equals( "A" ) ) {
                migratingColor = Color.RED;
            } else if( this.name.equals( "B" ) ) {
                migratingColor = Color.BLUE;
            } else if( this.name.equals( "C" ) ) {
                migratingColor = Color.GREEN;
            } else if( this.name.equals( "D" ) ) {
                migratingColor = Color.ORANGE;
            } else if( this.name.equals( "E" ) ) {
                migratingColor = Color.MAGENTA;
            } else {
                migratingColor = Color.YELLOW;
            } //END if-else-if STATEMENT
            Simulator.this.repaint();
            try {
                if( updateMessageSent ) { 
                    Thread.sleep( previousHostCost * 500 );
                } else {
                    Thread.sleep( 1000 );
                } //END if-else STATEMENT
            } catch( Exception e ) {
                e.printStackTrace();
            } //END try-catch BLOCK
            statusArea.append( "MIGRATION: The Agent " + this.name + " has migrated to Host-" + newHost + ".\n" );
            statusArea.setText( statusArea.getText() );
            migratingColor = null;
            if( this.name.equals( "A" ) ) {
                currentA = newHost;
            } else if( this.name.equals( "B" ) ) {
                currentB = newHost;                
            } else if( this.name.equals( "C" ) ) {
                currentC = newHost;
            } else if( this.name.equals( "D" ) ) {
                currentD = newHost;
            } else if( this.name.equals( "E" ) ) {
                currentE = newHost;
            } else {
                currentF = newHost;
            } //END if-else-if STATEMENT
            Simulator.this.repaint();
        } //END performMigration() METHOD
        
        public int calculatePreviousAndCurrentHostCosts() {
            if( !updateMessageSent ) {
                previousHostCost = 1000; //A Huge Value is assigned so it cannot become the shortest path
                if( currentHost==1 ) {
                    currentHostCost = costs[ 0 ];                    
                } else if( currentHost==2 ) {
                    currentHostCost = costs[ 1 ];                    
                } else if( currentHost==3 ) {
                    currentHostCost = costs[ 2 ];                    
                } else if( currentHost==4 ) {
                    currentHostCost = costs[ 3 ];                    
                } else if( currentHost==5 ) {
                    currentHostCost = costs[ 4 ];
                } else {
                    currentHostCost = costs[ 5 ];                    
                } //END if-else STATEMENT
                return 1;
            } //END if-else STATEMENT
            if( previousHost==1 && currentHost==2 ) {
                previousHostCost = costs[ 5 ];
                currentHostCost = costs[ 1 ];
            } else if( previousHost==2 && currentHost==1 ) {
                previousHostCost = costs[ 5 ];
                currentHostCost = costs[ 0 ];                
            } else if( previousHost==1 && currentHost==3 ) {
                previousHostCost = costs[ 6 ];
                currentHostCost = costs[ 2 ];                
            } else if( previousHost==3 && currentHost==1 ) {
                previousHostCost = costs[ 6 ];
                currentHostCost = costs[ 0 ];                
            } else if( previousHost==1 && currentHost==4 ) {
                previousHostCost = costs[ 7 ];
                currentHostCost = costs[ 3 ];                
            } else if( previousHost==4 && currentHost==1 ) {
                previousHostCost = costs[ 7 ];
                currentHostCost = costs[ 0 ];                
            } else if( previousHost==1 && currentHost==5 ) {
                previousHostCost = costs[ 8 ];
                currentHostCost = costs[ 4 ];                
            } else if( previousHost==5 && currentHost==1 ) {
                previousHostCost = costs[ 8 ];
                currentHostCost = costs[ 0 ];                
            } else if( previousHost==2 && currentHost==3 ) {
                previousHostCost = costs[ 9 ];
                currentHostCost = costs[ 2 ];                
            } else if( previousHost==3 && currentHost==2 ) {
                previousHostCost = costs[ 9 ];
                currentHostCost = costs[ 1 ];                
            } else if( previousHost==2 && currentHost==4 ) {
                previousHostCost = costs[ 10 ];
                currentHostCost = costs[ 3 ];                
            } else if( previousHost==4 && currentHost==2 ) {
                previousHostCost = costs[ 10 ];
                currentHostCost = costs[ 1 ];                
            } else if( previousHost==2 && currentHost==5 ) {
                previousHostCost = costs[ 11 ];
                currentHostCost = costs[ 4 ];                
            } else if( previousHost==5 && currentHost==2 ) {
                previousHostCost = costs[ 11 ];
                currentHostCost = costs[ 1 ];                
            } else if( previousHost==3 && currentHost==4 ) {
                previousHostCost = costs[ 12 ];
                currentHostCost = costs[ 3 ];                
            } else if( previousHost==4 && currentHost==3 ) {
                previousHostCost = costs[ 12 ];
                currentHostCost = costs[ 2 ];                
            } else if( previousHost==3 && currentHost==5 ) {
                previousHostCost = costs[ 13 ];
                currentHostCost = costs[ 4 ];                
            } else if( previousHost==5 && currentHost==3 ) {
                previousHostCost = costs[ 13 ];
                currentHostCost = costs[ 2 ];                
            } else if( previousHost==4 && currentHost==5 ) {
                previousHostCost = costs[ 14 ];
                currentHostCost = costs[ 4 ];                
            } else if( previousHost==5 && currentHost==4 ) {
                previousHostCost = costs[ 14 ];
                currentHostCost = costs[ 3 ];                
            } //END if-else-if STATEMENT
            return 0;
        } //END calculatePreviousAndCurrentHostCosts() METHOD
        
    } //END Agent INNER CLASS
    
    public void startNewSimulation() {
        statusArea.append( "A new simulation project has created.\n" );
        statusArea.setText( statusArea.getText() ); 
        OCEMAgentsConstants.NEW_SIMULATION = true;
        newSim.setEnabled( false );
        addAgent.setEnabled( true );
        startSim.setEnabled( true );
        
        data = new Object[ 15 ][ 2 ];
        costs = new int[ 15 ];
        for( int i=0; i<5; i++ ) {
            data[ i ][ 0 ] = paths[ i ];
            int cost = ( int )( Math.random() * OCEMAgentsConstants.COST_RANGE );
            if( cost==0 || cost==1 ) {
                cost += 5;
            } //END if STATEMENT
            data[ i ][ 1 ] = cost;
            costs[ i ] = cost;
        } //END for LOOP        
        for( int i=5; i<15; i++ ) {
            data[ i ][ 0 ] = paths[ i ];
            int cost = ( int )( Math.random() * ( OCEMAgentsConstants.COST_RANGE-5 ) );
            if( cost==0 || cost==1 ) {
                cost += 3;
            } //END if STATEMENT
            data[ i ][ 1 ] = cost;
            costs[ i ] = cost;
        } //END for LOOP
        tablePane.remove( costTable );
        this.remove( tablePane );
        costTable = new JTable( data, header );
        tablePane = new JScrollPane( costTable );
        tablePane.setBounds( 720, 160, 200, 280 );
        this.add( tablePane );
        this.updateUI();
        
        agentCounter = 0;
        currentA = 0;
        currentB = 0;
        currentC = 0;
        currentD = 0;
        currentE = 0;
        currentF = 0;
        
        this.repaint();
    } //END startNewSimulation() METHOD
    
    public void addAgent() {
        statusArea.append( "A new agent is added to the Simulation with name: " + agentNames[ agentCounter ] + "\n" );
        statusArea.setText( statusArea.getText() ); 
        
        agents[ agentCounter ] = new Agent( agentNames[ agentCounter ] );
        if( OCEMAgentsConstants.SIMULATION_RUNNING ) {
            agents[ agentCounter ].start();
        } //END if STATEMENT
        agentCounter++;
        
        
        if( agentCounter==6 ) {
            addAgent.setEnabled( false );
        } //END if STATEMENT
        this.repaint();
    } //END addAgent() METHOD

    public void startSimulation() {
        statusArea.append( "Simulation has started.\n" );
        statusArea.setText( statusArea.getText() ); 

        startSim.setEnabled( false );
        stopSim.setEnabled( true );

        OCEMAgentsConstants.SIMULATION_RUNNING = true;
        
        for( int a=0; a<agentCounter; a++ ) {
            agents[ a ].start();
        } //END for LOOP
        
        this.statPane.agents = this.agents;        
        Thread thread = new Thread( this.statPane );
        thread.start();
        
        this.repaint();
    } //END startNewSimulation() METHOD
    
    public void stopSimulation() {
        statusArea.append( "Simulation is stopped.\n" );
        statusArea.setText( statusArea.getText() ); 

        newSim.setEnabled( true );
        addAgent.setEnabled( false );
        startSim.setEnabled( false );
        stopSim.setEnabled( false );

        OCEMAgentsConstants.SIMULATION_RUNNING = false;
        
        this.repaint();
    } //END runNewSimulation() METHOD
    
    public void paint( Graphics g ) {
        super.paint( g );
        Graphics2D g2 = ( Graphics2D )g;

        g.setFont( new Font( "Arial", Font.BOLD, 20 ) );
        g.setColor( new Color( 0, 0, 64 ) );        
        g2.setStroke( new BasicStroke( 4 ) );
        g.drawOval( 290, 140, 80, 50) ;
        g2.setStroke( new BasicStroke( 2 ) );
        g.drawString( "H", 323, 173 );

        g.setColor( Color.black );
        g.drawOval( 90, 220, 80, 50 );
        g.drawString( " h1 ", 112, 253 );

        g.drawOval( 490, 220, 80, 50 );
        g.drawString( " h2 ", 512, 253 );
        
        g.drawOval( 90, 320, 80, 50 );
        g.drawString( " h3 ", 112, 353 );

        g.drawOval( 490, 320, 80, 50 );
        g.drawString( " h4 ", 512, 353 );
        
        g.drawOval( 290, 400, 80, 50 );
        g.drawString( " h5 ", 312, 433 );

        if( OCEMAgentsConstants.NEW_SIMULATION ) {
            g.setFont( new Font( "Arial", Font.BOLD, 12 ) );
            g2.setStroke( new BasicStroke( 1 ) );

            //LMS - H1
            g.drawLine( 290, 165, 130, 220 );
            g.drawString( String.valueOf( costs[ 0 ] ), 187, 193 );

            //LMS - H2
            g.drawLine( 370, 165, 530, 220 );
            g.drawString( String.valueOf( costs[ 1 ] ), 465, 193 );

            //LMS - H3
            g.drawLine( 330, 190, 130, 320 );
            g.drawString( String.valueOf( costs[ 2 ] ), 287, 210 );

            //LMS - H4
            g.drawLine( 330, 190, 530, 320 );
            g.drawString( String.valueOf( costs[ 3 ] ), 365, 210 );

            //LMS - H5
            g.drawLine( 330, 190, 330, 400 );
            g.drawString( String.valueOf( costs[ 4 ] ), 336, 270 );

            //H1 - H2
            g.drawLine( 170, 245, 490, 245 );
            g.drawString( String.valueOf( costs[ 5 ] ), 300, 243 );

            //H1 - H3
            g.drawLine( 130, 270, 130, 320 );
            g.drawString( String.valueOf( costs[ 6 ] ), 114, 300 );

            //H1 - H4
            g.drawLine( 170, 245, 490, 345 );
            g.drawString( String.valueOf( costs[ 7 ] ), 278, 275 );

            //H1 - H5
            g.drawLine( 130, 270, 330, 400 );
            g.drawString( String.valueOf( costs[ 8 ] ), 287, 393 );

            //H2 - H3
            g.drawLine( 490, 245, 170, 345 );
            g.drawString( String.valueOf( costs[ 9 ] ), 382, 291 );

            //H2 - H4
            g.drawLine( 530, 270, 530, 320 );
            g.drawString( String.valueOf( costs[ 10 ] ), 540, 300 );

            //H2 - H5
            g.drawLine( 530, 270, 330, 400 );
            g.drawString( String.valueOf( costs[ 11 ] ), 365, 393 );

            //H3 - H4
            g.drawLine( 170, 345, 490, 345 );
            g.drawString( String.valueOf( costs[ 12 ] ), 300, 343 );

            //H3 - H5
            g.drawLine( 130, 370, 290, 425 );
            g.drawString( String.valueOf( costs[ 13 ] ), 187, 408 );

            //H4 - H5
            g.drawLine( 530, 370, 370, 425 );
            g.drawString( String.valueOf( costs[ 14 ] ), 465, 408 );            
        } //END if STATEMENT
        
        //Display First Agent's Current State
        if( agentCounter>=1 ) {
            g.setColor( Color.RED );
            g.fillOval( agentA[ currentA ][ 0 ], agentA[ currentA ][ 1 ], 15, 15 );
        } //END if STATEMENT
        
        //Display Second Agent's Current State
        if( agentCounter>=2 ) {
            g.setColor( Color.BLUE );
            g.fillOval( agentB[ currentB ][ 0 ], agentB[ currentB ][ 1 ], 15, 15 );            
        } //END if STATEMENT
        
        //Display Third Agent's Current State
        if( agentCounter>=3 ) {
            g.setColor( Color.GREEN );
            g.fillOval( agentC[ currentC ][ 0 ], agentC[ currentC ][ 1 ], 15, 15 );
        } //END if STATEMENT
        
        //Display Fourth Agent's Current State
        if( agentCounter>=4 ) {
            g.setColor( Color.ORANGE );
            g.fillOval( agentD[ currentD ][ 0 ], agentD[ currentD ][ 1 ], 15, 15 );
        } //END if STATEMENT
        
        //Display Fifth Agent's Current State
        if( agentCounter>=5 ) {
            g.setColor( Color.MAGENTA );
            g.fillOval( agentE[ currentE ][ 0 ], agentE[ currentE ][ 1 ], 15, 15 );
        } //END if STATEMENT
        
        //Display Sixth Agent's Current State
        if( agentCounter>=6 ) {
            g.setColor( Color.YELLOW );
            g.fillOval( agentF[ currentF ][ 0 ], agentF[ currentF ][ 1 ], 15, 15 );
        } //END if STATEMENT
        
        if( migratingColor != null ) {
            g2.setStroke( new BasicStroke( 2 ) );
            g.setColor( migratingColor );
            g.drawLine( migratingPath[ 0 ], migratingPath[ 1 ], migratingPath[ 2 ], migratingPath[ 3 ] );
        } //END if-else STATEMENT

    } //END pain() METHOD
    
}
