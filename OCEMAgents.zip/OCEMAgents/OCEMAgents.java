/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author jMaster
 */

public class OCEMAgents extends JFrame {
    
    private JMenu file, project;
    private JMenuItem simulate, exit, newAgent, startSim, stopSim, settings;
    private JMenuBar bar;
    private JTabbedPane pane;
    private UIManager.LookAndFeelInfo looks[];
    
    private Simulator simPane;
    private Recorder statPane;
    
    public OCEMAgents() {
        super( "OCEMAgents" );
        this.setLayout( null );
        
        ImageIcon exitI = new ImageIcon( "Exit.png" );
        exit = new JMenuItem( "Exit", exitI );
        exit.setMnemonic( 'X');
        file = new JMenu( "File" );
        file.setMnemonic( 'F' );
        file.add( exit );

        ImageIcon newI = new ImageIcon( "New.png" );
        simulate = new JMenuItem( "New Simulation", newI );
        simulate.setMnemonic( 'N' );
        ImageIcon agentI = new ImageIcon( "Add.png" );
        newAgent = new JMenuItem( "Add New Agent", agentI );
        newAgent.setMnemonic( 'A' );
        ImageIcon startI = new ImageIcon( "Start.png" );
        startSim = new JMenuItem( "Start Simulation", startI );
        startSim.setMnemonic( 'S' );
        ImageIcon stopI = new ImageIcon( "Stop.png" );
        stopSim = new JMenuItem( "Stop Simulation", stopI );
        stopSim.setMnemonic( 'T' );
        ImageIcon settingsI = new ImageIcon( "Settings.png" );
        settings = new JMenuItem( "Settings", settingsI );
        settings.setMnemonic( 'G' );
        
        project = new JMenu( "Project" );
        project.setMnemonic( 'P' );
        project.add( simulate );
        project.add( newAgent );
        project.addSeparator();
        project.add( startSim );
        project.add( stopSim );
        project.addSeparator();
        project.add( settings );
        bar = new JMenuBar();
        bar.add( file );
        bar.add( project );
        
        pane = new JTabbedPane();
        statPane = new Recorder();
        simPane = new Simulator( statPane );
        pane.addTab( "Simulation", simPane );
        pane.addTab( "Statistics", statPane );
        pane.setBounds( 15, 15, 950, 600 );
        this.add( pane );

        simulate.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        simPane.startNewSimulation();
                    }
                }
        );
        
        startSim.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        simPane.startSimulation();
                    }
                }
        );
        
        newAgent.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        simPane.addAgent();
                    }
                }
        );
        
        stopSim.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        simPane.stopSimulation();
                    }
                }
        );
        
        settings.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        ConfigOCEMAgents config = new ConfigOCEMAgents( new JFrame() );
                    }
                }
        );
        
        exit.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        System.exit( 0 );
                    }
                }
        );
        
        looks = UIManager.getInstalledLookAndFeels();
        try {
            UIManager.setLookAndFeel( looks[ 3 ].getClassName() );
            SwingUtilities.updateComponentTreeUI( this );
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCk
        
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int h = dim.height;
        int w = dim.width;
        w = ( int )( w - 1000 ) / 2;
        h = ( int )( h - 700 ) / 2;
        
        this.setLocation( w, h-10 );
        this.setResizable( false );
        this.setJMenuBar( bar );
        this.setVisible( true );
        this.setSize( 1000, 700 );
    } //END REMiDiA() CONSTRUCTOR
    
    public static void main( String[] args ) {
        OCEMAgents r = new OCEMAgents();
        r.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    } //END main() METHOD
    
} //END REMiDiA CLASS