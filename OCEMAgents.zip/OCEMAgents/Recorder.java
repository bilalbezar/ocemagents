/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author jMaster
 */
public class Recorder extends JPanel implements Runnable {
    
    private String[] headerForward = { "Agent", "Migrations", "Baseline Approach", "Proposed Approach" };
    private Object[][] forwardData = new Object[ 6 ][ 4 ];
    private JTable forwardTable;
    private JScrollPane forwardScroll;

    private String[] headerUpdate = { "Agent", "Migrations", "No. of Update Messages", "Baseline Approach", "Proposed Approach" };
    private Object[][] updateMessageData = new Object[ 6 ][ 5 ];
    private JTable updateMessageTable;
    private JScrollPane updateScroll;

//    private String[] headerMessage = { "Agent", "No. of Messages", "Shortest Path Penalty", "Baseline Approach", "Proposed Approach" };
    private String[] headerMessage = { "Agent", "No. of Messages", "Baseline Approach", "Proposed Approach" };
    private Object[][] messageData = new Object[ 6 ][ 4 ];
    private JTable messageTable;
    private JScrollPane messageScroll;

    private String[] headerAck = { "Agent", "No. of Messages", "No. of Acks", "Baseline Approach", "Proposed Approach" };
    private Object[][] ackData = new Object[ 6 ][ 5 ];
    private JTable ackTable;
    private JScrollPane ackScroll;

    private JButton newSim, settings, addAgent, startSim, stopSim, sendMess;
    private UIManager.LookAndFeelInfo looks[];
    
    public Simulator.Agent[] agents;

    public Recorder() {
        this.setLayout( null );
        
        JLabel forwardLabel = new JLabel( "Comparison between the Costs for Forwarding Pointers", SwingConstants.CENTER );
        forwardLabel.setBounds( 10, 0, 930, 15 );
        forwardLabel.setFont( new Font( "Arial", Font.BOLD, 14 ) );
        this.add( forwardLabel );
        forwardTable = new JTable( forwardData, headerForward );
        forwardScroll = new JScrollPane( forwardTable );
        forwardScroll.setBounds( 10, 15, 930, 125 );
        this.add( forwardScroll );

        JLabel simLabel = new JLabel( "Comparison between the Costs for Update Messages", SwingConstants.CENTER );
        simLabel.setBounds( 10, 144, 930, 15 );
        simLabel.setFont( new Font( "Arial", Font.BOLD, 14 ) );
        this.add( simLabel );
        updateMessageTable = new JTable( updateMessageData, headerUpdate );
        updateScroll = new JScrollPane( updateMessageTable );
        updateScroll.setBounds( 10, 159, 930, 125 );
        this.add( updateScroll );

        ImageIcon csvI = new ImageIcon( "CSV.png" );
        JLabel mesageLabel = new JLabel( "Comparison between the Costs for Message Sending by Agents", SwingConstants.CENTER );
        mesageLabel.setBounds( 10, 288, 930, 15 );
        mesageLabel.setFont( new Font( "Arial", Font.BOLD, 14 ) );
        this.add( mesageLabel );
        messageTable = new JTable( messageData, headerMessage );
        messageScroll = new JScrollPane( messageTable );
        messageScroll.setBounds( 10, 303, 930, 125 );
        this.add( messageScroll );
        
        JLabel ackLabel = new JLabel( "Comparison between the Costs for Sending Acknowledgements", SwingConstants.CENTER );
        ackLabel.setBounds( 10, 432, 930, 15 );
        ackLabel.setFont( new Font( "Arial", Font.BOLD, 14 ) );
        this.add( ackLabel );
        ackTable = new JTable( ackData, headerAck );
        ackScroll = new JScrollPane( ackTable );
        ackScroll.setBounds( 10, 447, 930, 125 );
        this.add( ackScroll );

        looks = UIManager.getInstalledLookAndFeels();
        try {
            UIManager.setLookAndFeel( looks[ 3 ].getClassName() );
            SwingUtilities.updateComponentTreeUI( this );
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCk
        
    } //END StatisticsPane() CONSTRUCTOR
    
    public void run() {
        try {
            File fp = new File( OCEMAgentsConstants.READINGS_PATH + "\\fp.csv" );
            if( fp.exists() ) {
                fp.delete();
            } //END if STATEMENT
            RandomAccessFile raf = new RandomAccessFile( fp, "rw" );
            raf.writeBytes( "Time,Baseline Approach,Proposed Approach" );
            raf.writeBytes( "\n" );
            raf.close();
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK

        try {
            File um = new File( OCEMAgentsConstants.READINGS_PATH + "\\um.csv" );
            if( um.exists() ) {
                um.delete();
            } //END if STATEMENT
            RandomAccessFile raf = new RandomAccessFile( um, "rw" );
            raf.writeBytes( "Time,Baseline Approach,Proposed Approach,Baseline Cost,Proposed Cost" );
            raf.writeBytes( "\n" );
            raf.close();
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK

        try {
            File sp = new File( OCEMAgentsConstants.READINGS_PATH + "\\sp.csv" );
            if( sp.exists() ) {
                sp.delete();
            } //END if STATEMENT
            RandomAccessFile raf = new RandomAccessFile( sp, "rw" );
            raf.writeBytes( "Time,No. of Messages,Baseline Approach,Proposed Approach" );
            raf.writeBytes( "\n" );
            raf.close();
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
        
        try {
            File am = new File( OCEMAgentsConstants.READINGS_PATH + "\\am.csv" );
            if( am.exists() ) {
                am.delete();
            } //END if STATEMENT
            RandomAccessFile raf = new RandomAccessFile( am, "rw" );
            raf.writeBytes( "Time,Baseline Approach,Proposed Approach,Baseline Cost,Proposed Cost" );
            raf.writeBytes( "\n" );
            raf.close();
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
        
        int counter = 1;
        while( counter<=OCEMAgentsConstants.NUMBER_OF_SAMPLES ) {
            try {
                Thread.sleep( OCEMAgentsConstants.SAMPLE_WAIT_TIMEOUT );
                recordForwardingPointers( 20*counter );
                recordUpdateMessages( 20*counter );
                recordShortestPathCost( 20*counter );
                recordAcknowledgements( 20*counter );
            } catch( Exception e ) {
                e.printStackTrace();
            } //END try-catch BLOCK            
            counter++;
        } //END while LOOP
        System.exit( 0 );
    } //END run() METHOD
    
    public void recordForwardingPointers( int time ) {
        try {
            File fp = new File( OCEMAgentsConstants.READINGS_PATH + "\\fp.csv" );
            RandomAccessFile raf = new RandomAccessFile( fp, "rw" );
            String data = "";
            int baseline = 0;
            int proposed = 0;
            for( int a=0; a<6; a++ ) {
                Simulator.Agent agent = agents[ a ];
                if( agent!= null ) {
                    baseline += agent.getNoOfMigrations();
                    proposed += ( agent.getNoOfMigrations() - agent.getNoOfUpdateMessages() );
                } //END if-else STATEMENT
            } //END for LOOP

            data += time + ",";
            data += baseline + ",";
            data += proposed + "\n";
            
            raf.skipBytes( ( int )fp.length() );
            raf.writeBytes( data );
            raf.close();
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
    } //END recordForwardingPointers() METHOD
    
    public void recordUpdateMessages( int time ) {
        try {
            File um = new File( OCEMAgentsConstants.READINGS_PATH + "\\um.csv" );
            RandomAccessFile raf = new RandomAccessFile( um, "rw" );
            String data = "";
            int baseline = 0;
            int proposed = 0;
            int baselineCost = 0;
            int proposedCost = 0;

            for( int a=0; a<6; a++ ) {
                Simulator.Agent agent = agents[ a ];
                if( agent!= null ) {
                    baseline += agent.getNoOfMigrations();
                    proposed += agent.getNoOfUpdateMessages();
                    baselineCost += agent.getUpdateMessageCostBase();
                    proposedCost += agent.getUpdateMessageCostProp();
                } //END if-else STATEMENT
            } //END for LOOP

            data += time + ",";
            data += baseline + ",";
            data += proposed + ",";
            data += baselineCost + ",";
            data += proposedCost + "\n";
            
            raf.skipBytes( ( int )um.length() );
            raf.writeBytes( data );
            raf.close();            
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
    } //END recordUpdateMessages() METHOD
    
    public void recordShortestPathCost( int time ) {
        try {
            File sp = new File( OCEMAgentsConstants.READINGS_PATH + "\\sp.csv" );
            RandomAccessFile raf = new RandomAccessFile( sp, "rw" );
            String data = "";
            int messages = 0;
            int baseline = 0;
            int proposed = 0;

            for( int a=0; a<6; a++ ) {
                Simulator.Agent agent = agents[ a ];
                if( agent!= null ) {
                    messages += agent.getNoOfMessages();
                    baseline += agent.getMessageCostBase();
                    proposed += agent.getMessageCostProp();
                } //END if-else STATEMENT
            } //END for LOOP

            data += time + ",";
            data += messages + ",";
            data += baseline + ",";
            data += proposed + "\n";
            
            raf.skipBytes( ( int )sp.length() );
            raf.writeBytes( data );
            raf.close();            
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
    } //END recordShortestPathCost() METHOD
    
    public void recordAcknowledgements( int time ) {
        try {
            File sp = new File( OCEMAgentsConstants.READINGS_PATH + "\\am.csv" );
            RandomAccessFile raf = new RandomAccessFile( sp, "rw" );
            String data = "";
            int baseline = 0;
            int proposed = 0;
            int baselineCost = 0;
            int proposedCost = 0;

            for( int a=0; a<6; a++ ) {
                Simulator.Agent agent = agents[ a ];
                if( agent!= null ) {
                    baseline += agent.getNoOfMessages();
                    proposed += agent.getNoOfAcks(); 
                    baselineCost += agent.getAckCostBase();
                    proposedCost += agent.getAckCostProp();
                } //END if-else STATEMENT
            } //END for LOOP

            data += time + ",";
            data += baseline + ",";
            data += proposed + ",";
            data += baselineCost + ",";
            data += proposedCost + "\n";
            
            raf.skipBytes( ( int )sp.length() );
            raf.writeBytes( data );
            raf.close();            
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCK
    } //END recordAcknowledgements() METHOD
    
    public void generateForwardingPointersTable( Simulator.Agent[] agents ) {
        for( int a=0; a<6; a++ ) {
            Simulator.Agent agent = agents[ a ];
            if( agent!= null ) {
                forwardData[ a ][ 0 ] = "Agent " + agent.getAgentName();
                forwardData[ a ][ 1 ] = agent.getNoOfMigrations();
                forwardData[ a ][ 2 ] = agent.getNoOfMigrations();
                forwardData[ a ][ 3 ] = agent.getNoOfMigrations() - agent.getNoOfUpdateMessages();
            } else {
                forwardData[ a ][ 0 ] = "";
                forwardData[ a ][ 1 ] = "";
                forwardData[ a ][ 2 ] = "";
                forwardData[ a ][ 3 ] = "";
            } //END if-else STATEMENT
        } //END for LOOP
        forwardScroll.remove( forwardTable );
        this.remove( forwardScroll );
        forwardTable = new JTable( forwardData, headerForward );
        forwardScroll = new JScrollPane( forwardTable );
        forwardScroll.setBounds( 10, 15, 930, 125 );
        this.add( forwardScroll );
        this.updateUI();
    } //END generateForwardingPointersTable(() METHOD

    public void generateUpdateCostTable( Simulator.Agent[] agents ) {
        for( int a=0; a<6; a++ ) {
            Simulator.Agent agent = agents[ a ];
            if( agent!= null ) {
                updateMessageData[ a ][ 0 ] = "Agent " + agent.getAgentName();
                updateMessageData[ a ][ 1 ] = agent.getNoOfMigrations();
                updateMessageData[ a ][ 2 ] = agent.getNoOfUpdateMessages();
                updateMessageData[ a ][ 3 ] = agent.getUpdateMessageCostBase();
                updateMessageData[ a ][ 4 ] = agent.getUpdateMessageCostProp();                
            } else {
                updateMessageData[ a ][ 0 ] = "";
                updateMessageData[ a ][ 1 ] = "";
                updateMessageData[ a ][ 2 ] = "";
                updateMessageData[ a ][ 3 ] = "";
                updateMessageData[ a ][ 4 ] = "";
            } //END if-else STATEMENT
        } //END for LOOP
        updateScroll.remove( updateMessageTable );
        this.remove( updateScroll );
        updateMessageTable = new JTable( updateMessageData, headerUpdate );
        updateScroll = new JScrollPane( updateMessageTable );
        updateScroll.setBounds( 10, 159, 930, 125 );
        this.add( updateScroll );
        this.updateUI();
    } //END generateUpdateCostTable() METHOD
    
    public void generateMessageCostTable( Simulator.Agent[] agents ) {
        for( int a=0; a<6; a++ ) {
            Simulator.Agent agent = agents[ a ];
            if( agent!= null ) {
                messageData[ a ][ 0 ] = "Agent " + agent.getAgentName();
                messageData[ a ][ 1 ] = agent.getNoOfMessages();
//                messageData[ a ][ 2 ] = agent.getShortestPathCostPenalty();
                messageData[ a ][ 2 ] = agent.getMessageCostBase();
                messageData[ a ][ 3 ] = agent.getMessageCostProp();                
            } else {
                messageData[ a ][ 0 ] = "";
                messageData[ a ][ 1 ] = "";
//                messageData[ a ][ 2 ] = "";
                messageData[ a ][ 2 ] = "";
                messageData[ a ][ 3 ] = "";
            } //END if-else STATEMENT
        } //END for LOOP
        messageScroll.remove( messageTable );
        this.remove( messageScroll );
        messageTable = new JTable( messageData, headerMessage );
        messageScroll = new JScrollPane( messageTable );
        messageScroll.setBounds( 10, 303, 930, 125 );
        this.add( messageScroll );
        this.updateUI();
    } //END generateMessageCostTable() METHOD
    
    public void generateAcknowledgementCostTable( Simulator.Agent[] agents ) {
        for( int a=0; a<6; a++ ) {
            Simulator.Agent agent = agents[ a ];
            if( agent!= null ) {
                ackData[ a ][ 0 ] = "Agent " + agent.getAgentName();
                ackData[ a ][ 1 ] = agent.getNoOfMessages();
                ackData[ a ][ 2 ] = agent.getNoOfAcks();
                ackData[ a ][ 3 ] = agent.getAckCostBase();
                ackData[ a ][ 4 ] = agent.getAckCostProp();                
            } else {
                ackData[ a ][ 0 ] = "";
                ackData[ a ][ 1 ] = "";
                ackData[ a ][ 2 ] = "";
                ackData[ a ][ 3 ] = "";
                ackData[ a ][ 4 ] = "";
            } //END if-else STATEMENT
        } //END for LOOP
        ackScroll.remove( ackTable );
        this.remove( ackScroll );
        ackTable = new JTable( ackData, headerAck );
        ackScroll = new JScrollPane( ackTable );
        ackScroll.setBounds( 10, 447, 930, 125 );
        this.add( ackScroll );
        this.updateUI();
    } //END generateAcknowledgementCostTable() METHOD
    
} //END StatisticsPane CLASS
