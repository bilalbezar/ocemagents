/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jMaster
 */
public class OCEMAgentsConstants {

    public static int COST_RANGE = 15;
    
    public static int AGENT_TOTAL_STAY = 30;
    
    public static int UPDATE_TIMEOUT = 20;
    
    public static int SHORT_PATH_CALC_TIMEOUT = 1;
    
    public static int SHORT_PATH_SHARE_TIMEOUT = 3;
    
    public static int MIN_STAY_BEFORE_MIGRATION = 5;
    
    public static int MIN_WAIT_BEFORE_MESSAGE = 2;
    
    public static boolean NEW_SIMULATION = false;
    
    public static boolean SIMULATION_RUNNING = false;
    
    public static int NUMBER_AGENTS = 6;
    
    public static int NUMBER_OF_SAMPLES = 50;
    
    public static int SAMPLE_WAIT_TIMEOUT = 4000;
    
    public static String READINGS_PATH = "D:\\Dr. M. Bilal\\Research Work\\Reliable and Efficient Message Delivery for Mobile Agents\\Readings";

} //END OCEMAgentsConstants CLASS
