/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author jMaster
 */

public class ConfigOCEMAgents extends JDialog {
    
    private JMenu file;
    private JMenuItem simulate;
    private JMenuBar bar;
    private JButton ok, close;
    private JTextField costF, updateF, calcF, shareF, stayF, sendF, totalstayF;
    private UIManager.LookAndFeelInfo looks[];
    
    public ConfigOCEMAgents( JFrame parent ) {
        super( parent, "Settings", true );
        this.setLayout( null );
        
        ImageIcon closeI = new ImageIcon( "Close.png" );
        simulate = new JMenuItem( "Close", closeI );
        simulate.setMnemonic( 'C' );
        file = new JMenu( "File" );
        file.setMnemonic( 'F' );
        file.add( simulate );
        bar = new JMenuBar();
        bar.add( file );
        
        JLabel topLabel = new JLabel( "Configure OCEMAgents", SwingConstants.CENTER );
        topLabel.setBounds( 0, 10, 390, 20 );
        topLabel.setFont( new Font( "Helvatica", Font.BOLD, 14 ) );
        this.add( topLabel );
        
        JSeparator js = new JSeparator();
        js.setBounds( 0, 35, 400, 2 );
        this.add( js );
        
        JLabel label1 = new JLabel( "Cost Range Between Two Hosts" );
        label1.setBounds( 10, 55, 200, 20 );
        this.add( label1 );
        JTextField field11 = new JTextField( "2" );
        field11.setEditable( false );
        field11.setBounds( 220, 55, 50, 20 );
        this.add( field11 );
        JLabel label11 = new JLabel( "-", SwingConstants.CENTER );
        label11.setBounds( 270, 55, 10, 20 );
        this.add( label11 );
        costF = new JTextField( "" + OCEMAgentsConstants.COST_RANGE );
        costF.setBounds( 280, 55, 50, 20 );
        this.add( costF );
        
        JLabel label = new JLabel( "Max Stay on a Host" );
        label.setBounds( 10, 85, 200, 20 );
        this.add( label );
        totalstayF = new JTextField( "" + OCEMAgentsConstants.AGENT_TOTAL_STAY );
        totalstayF.setBounds( 220, 85, 60, 20 );
        this.add( totalstayF );
        JLabel label0 = new JLabel( "seconds" );
        label0.setBounds( 285, 85, 50, 20 );
        this.add( label0 );
        
        JLabel label2 = new JLabel( "Update Message Timeout" );
        label2.setBounds( 10, 115, 200, 20 );
        this.add( label2 );
        updateF = new JTextField( "" + OCEMAgentsConstants.UPDATE_TIMEOUT );
        updateF.setBounds( 220, 115, 60, 20 );
        this.add( updateF );
        JLabel label21 = new JLabel( "seconds" );
        label21.setBounds( 285, 115, 50, 20 );
        this.add( label21 );
        
        JLabel label3 = new JLabel( "Shortest Path Calc Timeout" );
        label3.setBounds( 10, 145, 200, 20 );
        this.add( label3 );
        calcF = new JTextField( "" + OCEMAgentsConstants.SHORT_PATH_CALC_TIMEOUT );
        calcF.setBounds( 220, 145, 60, 20 );
        this.add( calcF );
        JLabel label31 = new JLabel( "seconds" );
        label31.setBounds( 285, 145, 50, 20 );
        this.add( label31 );
        
        JLabel label5 = new JLabel( "Min Stay Before Migration" );
        label5.setBounds( 10, 175, 200, 20 );
        this.add( label5 );
        stayF = new JTextField( "" + OCEMAgentsConstants.MIN_STAY_BEFORE_MIGRATION );
        stayF.setBounds( 220, 175, 60, 20 );
        this.add( stayF );
        JLabel label51 = new JLabel( "seconds" );
        label51.setBounds( 285, 175, 50, 20 );
        this.add( label51 );
        
        JLabel label6 = new JLabel( "Min Wait Before Sending a Message" );
        label6.setBounds( 10, 205, 200, 20 );
        this.add( label6 );
        sendF = new JTextField( "" + OCEMAgentsConstants.MIN_WAIT_BEFORE_MESSAGE );
        sendF.setBounds( 220, 205, 60, 20 );
        this.add( sendF );
        JLabel label61 = new JLabel( "seconds" );
        label61.setBounds( 285, 205, 50, 20 );
        this.add( label61 );
        
        JSeparator js2 = new JSeparator();
        js2.setBounds( 0, 240, 400, 2 );
        this.add( js2 );
        
        ok = new JButton( "OK" );
        ok.setBounds( 195, 255, 80, 25 );
        this.add( ok );
        
        close = new JButton( "Cancel" );
        close.setBounds( 285, 255, 80, 25 );
        this.add( close );
       
        close.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        ConfigOCEMAgents.this.setVisible( false );
                    }
                }
        );
        
        simulate.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent ae) {
                        ConfigOCEMAgents.this.setVisible( false );
                    }
                }
        );
        
        looks = UIManager.getInstalledLookAndFeels();
        try {
            UIManager.setLookAndFeel( looks[ 3 ].getClassName() );
            SwingUtilities.updateComponentTreeUI( this );
        } catch( Exception e ) {
            e.printStackTrace();
        } //END try-catch BLOCk
        
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int h = dim.height;
        int w = dim.width;
        w = ( int )( w - 400 ) / 2;
        h = ( int )( h - 355 ) / 2;
        
        this.setLocation( w, h-10 );
        this.setResizable( false );
        this.setJMenuBar( bar );
        this.setSize( 400, 355 );
        this.setVisible( true );
    } //END ConfigOCEMAgents() CONSTRUCTOR
        
} //END ConfigOCEMAgents CLASS